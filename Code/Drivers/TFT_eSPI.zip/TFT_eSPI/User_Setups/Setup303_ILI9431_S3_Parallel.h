
#define USER_SETUP_ID 303

#define TFT_PARALLEL_8_BIT
		
#define ILI9341_DRIVER
#define CONFIG_SPIRAM_SUPPORT
//#define ST7796_DRIVER
//#define ILI9488_DRIVER

// ESP32 S3 pins used for the parallel interface TFT
#define TFT_CS    10
#define TFT_DC    11  // Data Command control pin - must use a GPIO in the range 0-31
#define TFT_RST   38

#define TFT_WR    12  // Write strobe control pin - must use a GPIO in the range 0-31
#define TFT_RD    -1

#define TFT_D0   4  // Must use GPIO in the range 0-31 for the data bus
#define TFT_D1   5  // so a single register write sets/clears all bits
#define TFT_D2   6
#define TFT_D3   7
#define TFT_D4   15
#define TFT_D5   16
#define TFT_D6   17
#define TFT_D7   18


#define LOAD_GLCD
#define LOAD_FONT2
#define LOAD_FONT4
#define LOAD_FONT6
#define LOAD_FONT7
#define LOAD_FONT8
#define LOAD_GFXFF

#define SMOOTH_FONT
