#ifndef _PNGAUX_H_INCLUDED
#define _PNGAUX_H_INCLUDED
#include <Arduino.h>

typedef struct pngObject
{
	unsigned short w, h;
	unsigned int* data;
};

void setSetXY2function(void (*setXY2func)(short, short, short, short));
bool loadPngFromSDcard(char * fileName, pngObject* pngObj,bool usePSRAM = true, bool littleEndian = false);
bool displayPngObj(unsigned short x, unsigned short y, pngObject* pngObj); // Only works for RGB565 frame buffer, image must fully fit in screen

#endif
