#include "pngAux.h"
//#include "SPI.h"
#include <PNGdec.h>
#include "FS.h"
#include "SD.h"
#include "SPIFFS.h"
#include <inttypes.h>

// Functions to access a file on the SD card
File _myfile;

// SPIFFS
// File root = fs.open(dirname);
// file.read()
// file.close();

PNG  _png;
unsigned int _PNGendianessFlag;

void (*pngSetXY2func)(short, short, short, short);

void* myOpen(const char* filename, int32_t* size)
{
	Serial.printf("Attempting to open %s\n", filename);
	_myfile = SD.open(filename);
	*size = _myfile.size();
	return &_myfile;
}

void myClose(void* handle)
{
	if (_myfile) _myfile.close();
}

int32_t myRead(PNGFILE* handle, uint8_t* buffer, int32_t length)
{
	if (!_myfile) return 0;
	return _myfile.read(buffer, length);
}

int32_t mySeek(PNGFILE* handle, int32_t position)
{
	if (!_myfile) return 0;
	return _myfile.seek(position);
}

// Function to draw pixels to the display
unsigned short* _pngBuffer;

void PNGDraw(PNGDRAW* pDraw)
{
	_png.getLineAsRGB565(pDraw, _pngBuffer, _PNGendianessFlag, 0xffffffff);
	_pngBuffer += _png.getWidth();
}

bool loadPngFromSDcard(char * fileName, pngObject* pngObj,bool usePSRAM, bool littleEndian)
{
	int pngStatus;
	if (littleEndian)
	{
		_PNGendianessFlag = PNG_RGB565_LITTLE_ENDIAN;
	}
	else
	{
		_PNGendianessFlag = PNG_RGB565_BIG_ENDIAN;
	}
	pngStatus = _png.open(fileName, myOpen, myClose, myRead, mySeek, PNGDraw);
	if (pngStatus == PNG_SUCCESS)
	{
		printf("image specs: (%d x %d), %d bpp, pixel type: %d\n", _png.getWidth(), _png.getHeight(), _png.getBpp(), _png.getPixelType());
		if (usePSRAM)
		{
			_pngBuffer = (unsigned short*)ps_malloc(_png.getWidth() * _png.getHeight() * 2);
		}
		else
		{
			_pngBuffer = (unsigned short*)malloc(_png.getWidth() * _png.getHeight() * 2);
		}
		if (_pngBuffer == NULL)
		{
			_png.close(); 
			return false;
		}
		pngObj->w = _png.getWidth();
		pngObj->h = _png.getHeight();
		pngObj->data = (unsigned int*)_pngBuffer;
		pngStatus = _png.decode(NULL, 0);
		_png.close();
		return true;
	}
	else
		return false;
}
/*
bool displayPngObj(unsigned short x, unsigned short y, pngObject* pngObj) // Only works for RGB565 frame buffer, image must fully fit in screen
{
	pngSetXY2func(x, y, pngObj->w + x - 1, pngObj->h + y - 1);
	SPI.writeBuffer((unsigned int*)pngObj->data, pngObj->w * pngObj->h * 2 / 4);
	return true;
}

void setSetXY2function(void (*setXY2func)(short, short, short, short))
{
	pngSetXY2func = setXY2func;
}
*/